# Nonsense Machine MCP

TypeScript local stdio MCP. `npm ci && npm run build && npm pack && npm test`.

`generate_nonsense(word)` creates fresh server-side nonsense, a random token and UUID. `verify_nonsense(receiptId)` returns that process’s recorded result. Receipts are in-memory, bounded to 1000, and lost on restart. Complete generation results are logged to stderr; stdout is MCP-only. This is a toy execution/provenance test, not a security or identity service.

Public packaging includes compiled JS and the licence. No secrets or private source are included. Requires Node 20+ and npm/npx. No hosted server or npm publication.
