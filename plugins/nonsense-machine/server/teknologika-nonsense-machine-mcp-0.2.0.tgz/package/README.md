# Nonsense Machine MCP

TypeScript local stdio server, exposing only `endpoint`. All workflow instructions are returned by the server at each step: instructions → generate → remote roll_dice → verify. The skill only says to call endpoint for instructions.

`npm ci && npm run build && npm pack && npm test`. Requires Node 20+ and npm/npx. Tests perform a real network call to the public no-auth dice MCP used in OpenAI’s quickstart. Only sides=20 is sent remotely, not the user’s word or receipt. Network failures return explicit recovery instructions.

Receipts are process-local and bounded to 1000. Compiled code is distributed publicly; no secrets. Production can preserve the endpoint contract in a WordPress/PHP MCP.
