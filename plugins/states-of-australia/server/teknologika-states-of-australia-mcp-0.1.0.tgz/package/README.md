# States of Australia MCP

Local TypeScript stdio test server. Build with `npm ci && npm test && npm pack`.

One tool, `explore_state`, accepts only `state`. Server mapping selects capital (NSW/WA), landmark (VIC/SA), or fact (QLD/TAS). Accepts full names and abbreviations. Excludes ACT/NT as territories. Results include an execution UUID, also logged on stderr. Stdout is reserved for MCP.

Run the archive through `npx --yes --package /absolute/path/to/teknologika-states-of-australia-mcp-0.1.0.tgz states-of-australia-mcp`. Requires Node 20+ and npm. First launch downloads dependencies.

Source lives in this private repo; compiled JS and licence are shipped in the public plugin. The distributed code is not secret. No npm registry publication is needed.

Production target: a PHP MCP endpoint in WordPress, keeping the same explore_state input and result contract. This prototype does not change WordPress.
